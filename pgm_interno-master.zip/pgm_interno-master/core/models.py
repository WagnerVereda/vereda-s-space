from django.db import models


class Configuracoes(models.Model):
    nome = models.CharField(max_length=255)
    valor = models.CharField(max_length=255)
    unidade =  models.CharField(max_length=255)
    descricao = models.TextField(null=True, blank=True)
    def __str__(self):
        return self.nome

class Parte(models.Model):
    nome = models.CharField(max_length=255)
    pertinente = models.BooleanField(default=False)
    def __str__(self):
        return self.nome

class MovimentacaoTag(models.Model):
    nome = models.CharField(max_length=255)
    pertinente = models.BooleanField(default=False)
    def __str__(self):
        return self.nome



class SegundaInstancia(models.Model):

    seq = models.IntegerField()
    ano = models.IntegerField()

    processo = models.CharField(max_length=255)
    segredo_de_justica = models.BooleanField(default=False)
    outros_numeros = models.CharField(max_length=255, null=True, blank=True)
    classe  = models.CharField(max_length=555)
    assunto = models.CharField(max_length=855)
    origem = models.CharField(max_length=855)
    distribuicao = models.CharField(max_length=855)
    relator = models.CharField(max_length=855)
    volume_apenso = models.CharField(max_length=855)
    valor_da_acao = models.DecimalField(max_digits=20, decimal_places=2, null=True, blank=True)

    parte = models.ManyToManyField(Parte, through='Posicao')

    info_url = models.CharField(max_length=855)

    data_consulta = models.DateField(auto_now=True)
    data_inclusao = models.DateField(auto_now_add=True, null=True)

class PrimeiraInstancia(models.Model):

    seq = models.IntegerField()
    ano = models.IntegerField()
    v = models.IntegerField()

    nuprocessounificadoformatado = models.CharField(max_length=50)

    data_inicial = models.DateField(blank=True, null=True)

    moeda = models.CharField(max_length=20, blank=True)
    valor_acao_float = models.FloatField(blank=True, null=True)

    vara = models.CharField(max_length=300, blank=True)
    juiz = models.CharField(max_length=300, blank=True)
    area = models.CharField(max_length=50, blank=True)
    classe = models.CharField(max_length=300, blank=True)
    assunto = models.CharField(max_length=300, blank=True)
    outros_assuntos = models.CharField(max_length=2000, blank=True)
    tramitacao_prioritaria = models.CharField(max_length=50, blank=True)
    incidente_ou_execucao = models.CharField(max_length=400, blank=True)
    extinto_suspenso = models.CharField(max_length=50, blank=True)
    processo = models.CharField(max_length=100, blank=True)
    processo_principal = models.CharField(max_length=300, blank=True)
    outros_numeros = models.TextField(blank=True)
    apensado_ao = models.CharField(max_length=300, blank=True)
    entranhado_ao = models.CharField(max_length=1000, blank=True)
    unificado_ao = models.CharField(max_length=100, blank=True)
    distribuicao = models.CharField(max_length=100, blank=True)
    recebido_em = models.CharField(max_length=100, blank=True)
    controle = models.CharField(max_length=30, blank=True)
    cdas = models.CharField(max_length=300, blank=True)
    dados_da_precatoria = models.CharField(max_length=300, blank=True)
    local_fisico = models.CharField(max_length=1000, blank=True)
    recurso = models.CharField(max_length=300, blank=True)
    acao_incidental = models.CharField(max_length=300, blank=True)
    peticao_diversa = models.CharField(max_length=300, blank=True)
    segredo_de_justica = models.BooleanField(default=False, blank=True)
    digital = models.BooleanField(default=False, blank=True)

    parte = models.ManyToManyField(Parte, through='Posicao')

    # sei = models.CharField(null=True, blank=True, max_length=255)
    # unidade = models.ManyToManyField(Unidade, null=True, blank=True)
    # objeto = models.ManyToManyField(Objeto, null=True, blank=True)
    # complementoobjeto = models.ManyToManyField(ComplementoObjeto, null=True, blank=True)

    info_url = models.CharField(max_length=855)
    data_consulta = models.DateField(auto_now=True)
    data_inclusao = models.DateField(auto_now_add=True, null=True)

    class Meta:
        unique_together = ['seq', 'ano','v',]

    def __str__(self):
        return self.nuprocessounificadoformatado


class Numero1Instancia(models.Model):
    segunda_instancia =  models.ForeignKey(SegundaInstancia, on_delete=models.CASCADE, related_name='numero_1_instancia')
    n_primeira_instancia = models.CharField(max_length=255)
    foro = models.CharField(max_length=255, null=True, blank=True)
    vara = models.CharField(max_length=255, null=True, blank=True)
    juiz = models.CharField(max_length=255, null=True, blank=True)
    obs = models.TextField(null=True, blank=True)

class Movimentacao(models.Model):
    ordem = models.IntegerField()
    data = models.DateField()
    link0 = models.CharField(max_length=1200, null=True, blank=True)
    link1 = models.CharField(max_length=1200, null=True, blank=True)
    movimentacaotag = models.ForeignKey(MovimentacaoTag, on_delete=models.PROTECT)
    movimentacaodescricao = models.TextField(null=True, blank=True)
    segunda_instancia = models.ForeignKey(SegundaInstancia, on_delete=models.CASCADE, null=True)
    primeira_instancia = models.ForeignKey(PrimeiraInstancia, on_delete=models.CASCADE, null=True)


class Posicao(models.Model):
    posicao = models.CharField(max_length=255)
    parte = models.ForeignKey(Parte, on_delete=models.CASCADE)
    segunda_instancia = models.ForeignKey(SegundaInstancia, on_delete=models.CASCADE, null=True)
    primeira_instancia = models.ForeignKey(PrimeiraInstancia, on_delete=models.CASCADE, null=True)



# class partes(models.Model):
#     segunda_instancia =  models.ForeignKey(segunda_instancia, on_delete=models.CASCADE)
#     posicao = models.CharField(max_length=255)
#     nome  = models.TextField()



# class Processo(models.Model):
#     nome = models.CharField(max_length=128)
#     parte = models.ManyToManyField(Person, through='Posicao')
#
#     def __str__(self):              # __unicode__ on Python 2
#         return self.nome
