from bs4 import BeautifulSoup as bs
from seleniumrequests import Chrome
import re
from unidecode import unidecode
from core.models import *
from django import db

def scrapper_2_instancia(sentido='progressivo'):

    def calculo_cnj(seq, ano, j, tr, vara):
        vara = str(vara)
        while len(vara) < 4:
            vara = vara + '0'
        n = int(f'{seq}{ano}{j}{tr}{vara}00')
        d = str(98 - n%97)
        if len(d) == 1:
            d = '0' + d
        seq = str(seq)
        while len(seq) < 7:
            seq = '0' + seq
        return f'{seq}-{d}.{ano}.{j}.{tr}.{vara}'


    driver = Chrome()

    driver.get('https://esaj.tjsp.jus.br/sajcas/login?service=https%3A%2F%2Fesaj.tjsp.jus.br%2Fesaj%2Fj_spring_cas_security_check')
    driver.find_element_by_xpath('//*[@id="usernameForm"]').send_keys('01378744055')
    driver.find_element_by_xpath('//*[@id="passwordForm"]').send_keys('rasengan')
    driver.find_element_by_xpath('//*[@id="pbEntrar"]').click()
    driver.get('https://esaj.tjsp.jus.br/cposg/open.do')

    vazio = 0

    if SegundaInstancia.objects.all().exists():
        seq = SegundaInstancia.objects.latest('seq').seq + 1
    else:
        seq = 2262000

    while True:

        params = {

        'conversationId': '',
        'paginaConsulta': '1',
        'localPesquisa.cdLocal': '-1',
        'cbPesquisa': 'NUMPROC',
        'tipoNuProcesso': 'UNIFICADO',
        'dePesquisaNuUnificado': calculo_cnj(seq, 2019, 8, 26, 0),
        'dePesquisa': '',
        'uuidCaptcha': '',
        }

        r = driver.request('GET', 'https://esaj.tjsp.jus.br/cposg/search.do', params=params)

        res = {'seq': seq,
               'info_url' : r.url}

        sp = bs(r.content, 'html5lib')

        if sp.find(attrs={'role':'alert'}) and not sp.find(text={re.compile('Será necessário informar uma senha para acessar processos em segredo de justiça')}):
            vazio +=1

        else:
            vazio = 0
            if sp.find(text={re.compile('Será necessário informar uma senha para acessar processos em segredo de justiça')}):
                res['segredo_de_justica'] = True
            else:
                tabela_dados_gerais = sp.findAll(attrs={'class':'secaoFormBody'})[1].find('tbody')
                for entrada in tabela_dados_gerais.findAll('tr'):
                    try:
                        k = entrada.find('label').get_text()
                        v = entrada.find('span').get_text()
                        res[k] = v
                    except:
                        pass

                tabela_1_instancia = sp.find(text=re.compile('Números de 1ª Instância')).findAllNext('table')[1].find('tbody')
                if tabela_1_instancia:
                    coleta = []
                    for entrada in tabela_1_instancia.findAll('tr'):
                        coleta.append({k: v.get_text().strip() for k,v in zip(['n_primeira_instancia', 'foro', 'vara', 'juiz', 'obs'], entrada.findAll('td')) })
                    if len(coleta) > 0:
                        res['numeros_1_instancia'] = coleta

                tabela_partes = sp.find(text=re.compile('Partes do Processo')).findNext('table').find('tbody')

                coleta = []
                for entrada in tabela_partes.findAll('tr'):
                    coleta.append({'posicao' : entrada.findAll('td')[0].find('span').get_text(),
                                   'nome': entrada.findAll('td')[1].next.strip()})
                if len(coleta) > 0:
                    res['partes'] = coleta

                if sp.find(attrs={'id':'tabelaTodasMovimentacoes'}):
                    coleta = []
                    for _, entrada in enumerate(sp.find(attrs={'id':'tabelaTodasMovimentacoes'}).findAll('tr')[::-1]):
                        linhas = entrada.findAll('td')
                        rp = {'ordem': _}
                        rp['data'] = datetime.datetime.strptime(linhas[0].get_text().strip(), '%d/%m/%Y').date()
                        if linhas[1].find('a'):
                            rp['link0'] = linhas[1].find('a').get('href')
                        if linhas[2].find('a'):
                            rp['link1'] = linhas[2].find('a').get('href')
                            rp['movimentacaotag'] =  linhas[2].find('a').get_text().strip()
                        else:
                            rp['movimentacaotag'] = linhas[2].next.strip()
                        rp['movimentacaotag'], x = MovimentacaoTag.objects.get_or_create(nome=rp['movimentacaotag'])
                        rp['movimentacaodescricao'] = linhas[2].find('span').get_text()
                        coleta.append(rp)
                    if len(coleta)>0:
                        res['movimentacoes'] = coleta

            res = {k.replace(':','').lower().strip(): v for k,v in res.items()}
            res = {unidecode(k).replace(' ','_').replace('_/_','_'): (v.strip() if isinstance(v, str) else v) for k,v in res.items()}

            if 'valor_da_acao' in res.keys():
                res['valor_da_acao'] = float(res['valor_da_acao'].replace('.','').replace(',','.'))

            SegundaInstancia_m = SegundaInstancia(**{k:v for k,v in res.items() if k not in ['partes','numeros_1_instancia', 'movimentacoes' ]})
            SegundaInstancia_m.save()

            if 'partes' in res.keys():
                partes = [{k: (v.lower().strip().replace(':','') if k =='posicao' else v) for k,v in i.items()} for i in res['partes']]

                for p in partes:
                    p = Parte.objects.get_or_create(nome = p['nome']), p['posicao']
                    posicao = Posicao(segunda_instancia=SegundaInstancia_m, parte=p[0][0], posicao=p[1])
                    posicao.save()

            if 'numeros_1_instancia' in res.keys():
                n_1_instancia = [{k:v for k,v in i.items() if v !='-'} for i in res['numeros_1_instancia']]
                Numero1Instancia.objects.bulk_create([Numero1Instancia(**i, segunda_instancia=SegundaInstancia_m) for i in n_1_instancia])

            if 'movimentacoes' in res.keys():
                m = [Movimentacao(**i, segunda_instancia=SegundaInstancia_m) for i in res['movimentacoes']]
                Movimentacao.objects.bulk_create(m)

        seq += 1
        if vazio == 25:
            break

        print(seq, vazio)
