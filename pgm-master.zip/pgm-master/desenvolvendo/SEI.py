from selenium import webdriver
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.keys import Keys
import datetime
import time
import re

# driver = webdriver.Chrome(r'C:\Anaconda3\chromedriver_win32\chromedriver.exe')
driver = webdriver.Chrome(r'/home/ezequiel/Desktop/chromedriver')

cnj = 123456
interessado = 'Interessados3'

# tela de login
driver.get('https://sip.prefeitura.sp.gov.br/sip/login.php?sigla_orgao_sistema=PMSP&sigla_sistema=SEI')
driver.find_element_by_id('txtUsuario').send_keys('d858414')
time.sleep(0.1)
driver.find_element_by_id('pwdSenha').send_keys('013450Ab')
select  = Select(driver.find_element_by_id('selOrgao'))
select.select_by_value('11')
driver.find_element_by_id('sbmLogin').click()

# iniciar processo
driver.find_element_by_xpath('//*[@id="main-menu"]/li[3]/a').click()

# Comunicação de decisão judicial e pedido de informação
driver.find_element_by_xpath('//*[@id="tblTipoProcedimento"]/tbody/tr[9]/td/a[2]').click()

# Parametros da tela
driver.find_element_by_id('txtDescricao').send_keys(cnj)

# Assunto
driver.find_element_by_id('imgPesquisarAssuntos').click()
driver.switch_to_window(driver.window_handles[1])
driver.find_element_by_id('txtPalavrasPesquisaAssuntos').send_keys('adm civ')
driver.find_element_by_id('btnPesquisar').click()
driver.find_element_by_xpath('//*[@id="lnkInfraT-1325"]/img').click()
driver.switch_to_window(driver.window_handles[0])

time.sleep(0.1)

# Interessado

driver.find_element_by_id('txtInteressadoProcedimento').send_keys(interessado)
driver.find_element_by_id('txtInteressadoProcedimento').send_keys(Keys.ENTER)
try:
    alert = driver.switch_to.alert
    alert.accept()
except:
    pass

driver.find_element_by_id('optRestrito').click()
while 'Documento Preparatório' not in driver.page_source:
    time.sleep(0.1)
driver.find_element_by_id('btnSalvar').click()

# nova pagina
a = driver.page_source
driver.switch_to_frame(driver.find_element_by_id('ifrArvore'))
id_procedimento = re.search('(?<=id_procedimento=)\d+', driver.current_url).group()
numero_sei = driver.find_element_by_id(f'span{id_procedimento}').text

# inserir documento
driver.switch_to_default_content()
driver.switch_to_frame(driver.find_element_by_id('ifrVisualizacao'))
driver.find_element_by_xpath('//*[@id="divArvoreAcoes"]/a[1]/img').click()
driver.find_element_by_xpath('//*[@id="tblSeries"]/tbody/tr[1]/td/a[2]').click()

# # mandado de citação
select = Select(driver.find_element_by_id('selSerie'))
select.select_by_value('2188')
# # data do mandado de citação
driver.find_element_by_id('txtDataElaboracao').send_keys(datetime.datetime.strftime(datetime.datetime.now(), '%d/%m/%Y'))
# # nato-digital
driver.find_element_by_id('lblNato').click()
# # restrito
driver.find_element_by_id('lblRestrito').click()

driver.find_element_by_id('filArquivo').send_keys('/home/ezequiel/Desktop/sample.pdf')

driver.find_element_by_id('btnSalvar').click()

driver.find_element_by_id(f'span{id_procedimento}').click()
