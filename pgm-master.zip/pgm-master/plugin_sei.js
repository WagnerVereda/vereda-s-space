


link = 'https://sei.prefeitura.sp.gov.br/sei/controlador.php?acao=procedimento_gerar&acao_origem=procedimento_escolher_tipo&acao_retorno=procedimento_escolher_tipo&id_tipo_procedimento=100000591&infra_sistema=100000100&infra_unidade_atual=110001902&infra_hash=e94edab2ce90432db67f1113413f0053f6d813dd4140192a9078e734c95f1cb9'

// $('#selTipoProcedimento').val('100000591')

var assunto = '<option value="1325">4.0.01.00.03 - Processos administrativos relativos a ações cíveis</option>';
$('#selAssuntos').append(assunto);

$('#optRestrito').click();

<soap:Header/>

                        <soap:Body>

                        <proc:autuarProcessoEletronico.v1.0.Entrada.Mensagem>

                            <sglSistema>SOA</sglSistema>

                            <txtIdentificacaoServico>SOA</txtIdentificacaoServico>

                            <codUnidade>@codUnidade</codUnidade>

                            <codTipoProcedimento>@codProcedimentoSEI</codTipoProcedimento>

                            <txtResumo>@objetivo</txtResumo>

                            <LstAssuntos>

                                <ass:AssuntoProcesso>

                                    <ass:codAssunto>@attunto talç</ass:codAssunto>

                                    <ass:txtDescricaoAssunto>etc</ass:txtDescricaoAssunto>

                                </ass:AssuntoProcesso>

                            </LstAssuntos>

                            <LstInteressados />

                            <txtObservacaoProcesso>@anotacao</txtObservacaoProcesso>

                            <LstDocumentos />

                            <ListaProcedimentosRelacionados />

                        </proc:autuarProcessoEletronico.v1.0.Entrada.Mensagem>

                        </soap:Body>

                    </soap:Envelope>").Replace("'", "\"");
