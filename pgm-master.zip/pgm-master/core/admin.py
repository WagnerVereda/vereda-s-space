# from django.contrib import admin
# from .models import Unidade, Objeto, ComplementoObjeto, ModelosPeticoes, Informacoes
#
# admin.site.register(Informacoes)
# admin.site.register(Unidade)
# admin.site.register(Objeto)
# admin.site.register(ComplementoObjeto)
# admin.site.register(ModelosPeticoes)
