# from django.urls import path
#
# from . import views
#
# urlpatterns = [
#     path('', views.index, name='index'),
#     path('novas_acoes', views.novas_acoes, name='novas_acoes'),
#     path('acoes_cadastradas', views.acoes_cadastradas, name='acoes_cadastradas'),
#     path('modelos', views.modelos, name='modelos'),
#     #path('cb', views.captcha_break, name='captcha_break'),
# ]
