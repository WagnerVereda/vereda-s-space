# from django.shortcuts import render
# from rest_framework.decorators import api_view
# from django.http import HttpResponse
# import re
# from core.models import *
# from utils import login, scrapper
# from django.contrib.auth.decorators import login_required
# import datetime
# from utils import login, scrapper
# from docx import Document
# from django.conf import settings
# import os
# import tempfile
# from django.http import JsonResponse, FileResponse
# from api.models import *
# from django.views.decorators.csrf import csrf_exempt
# #import cv2
# import base64
#
# # @csrf_exempt
# # def captcha_break(request):
#
# #     if request.method == 'GET':
# #         return HttpResponse('oi olá como vai você')
#
# #     else:
# #         data = request.POST.dict()
# #         imgcode = data['img'][22:]
#
# #         imgtempfile = tempfile.NamedTemporaryFile(suffix='.png')
#
# #         with open(imgtempfile.name, 'wb') as imgfile:
#
# #             imgfile.write(base64.b64decode(imgcode))
#
# #             img = cv2.imread(imgfile.name, 0)
# #             img = img[0:40, 0:180]
# #             kernel = np.ones((6, 6), np.uint8)
# #             scale = 6
# #             width = int(img.shape[1] * scale)
# #             height = int(img.shape[0] * scale)
# #             dim = (width, height)
#
# #             img = cv2.resize(img, dim, interpolation=cv2.INTER_AREA)
#
# #             img = cv2.fastNlMeansDenoising(img, h=5)
# #             img = cv2.dilate(img, kernel, iterations=3)
# #             img = cv2.erode(img, kernel, iterations=3)
# #             img = cv2.threshold(img, 220,255, cv2.THRESH_BINARY)[1]
#
# #             cv2.imwrite(b, img)
# #             captcha_text = pytesseract.image_to_string(img)
#
# #         return JsonResponse({'captcha': captcha_text})
#
#
#
#
# @login_required
# def index(request):
#     return render(request, 'core/0_index.html')
#
# @login_required
# @api_view(['GET', 'POST'])
# def novas_acoes(request):
#     if request.method == 'GET':
#         return render(request, 'core/2_novas_acoes_index.html')
#
#     else:
#         data = request.POST.dict()
#
#         if data['origem'] == 'cnj_usuario':
#
#             data['nuprocessounificadoformatado'] = re.sub('[^0-9]', '', data['cnj_usuario'])
#
#             informacoes_query = Informacoes.objects.filter(nuprocessounificadoformatado=data['nuprocessounificadoformatado'])
#
#             if len(informacoes_query) == 0:
#
#                 res = {'nuprocessounificadoformatado': data['nuprocessounificadoformatado'],
#                        'fonte_comunicacao' : 'usuario',
#                        'razao_comunicacao': 'intimacao'}
#
#                 processo_recebido = ProcessoRecebido(**res)
#                 processo_recebido.save()
#
#                 s_esaj = login.get_esaj_logged_session()
#                 informacao = scrapper.get_tjsp(s_esaj, processo_recebido)
#                 processo_recebido.processado = True
#                 processo_recebido.resultado = 'Inserido na db'
#                 processo_recebido.informacao = informacao
#                 processo_recebido.save()
#
#             else:
#                 informacao = informacoes_query[0]
#
#             partesquery = Partes.objects.filter(informacao=informacao)
#             mandadosquery = Mandados.objects.filter(informacao=informacao)
#             unidadequery = Unidade.objects.all()
#
#             context = {'partes': partesquery.values('id', 'nome'),
#                        'intimacoes': mandadosquery.values('id', 'codigo_validacao'),
#                        'unidade': unidadequery.values()}
#
#             return render(request, 'core/2_grid_intimacao.html', context=context)
#
#         if data['origem'] == 'criar_processo':
#
#             params = request.POST.dict()
#             print(params)
#
#         #     m = IntimacaoRecebida()
#         #     m.parte_citada = Partes.objects.get(pk=params['parte_citada'])
#         #     m.parte_oposta = Partes.objects.get(pk=params['parte_contraria'])
#         #     intimacao = Intimacao.objects.get(pk=params['intimacao'])
#         #     m.intimacao = intimacao
#         #     m.informacao = Informacoes.objects.get(pk=intimacao.informacao_id)
#         #     m.unidade = Unidade.objects.get(pk=params['unidade'])
#         #     m.usuario = User.objects.get(pk=request.user.id)
#         #     m.save()
#         #
#         #
#             return HttpResponse('SEI e SIAJD Criados')
#
# @login_required
# @api_view(['GET', 'POST'])
# def acoes_cadastradas(request):
#     if request.method == 'GET':
#
#         query = IntimacaoRecebida.objects.all().prefetch_related('informacao',
#                                                         'parte_citada',
#                                                         'parte_oposta',
#                                                         'intimacao',
#                                                         'unidade',
#                                                         'usuario')
#
#         context = []
#
#         for m in query:
#             entrada = {
#                        'ordem': m.id,
#                        'processo': m.informacao.processo,
#                        'parte_citada': m.parte_citada.nome,
#                        'parte_oposta': m.parte_oposta.nome,
#                        'intimacao': m.intimacao.codigo_validacao,
#                        'dia': datetime.datetime.strftime(m.hora_citacao, '%d/%m/%Y'),
#                        'hora': datetime.datetime.strftime(m.hora_citacao, '%H:%M:%S'),
#                        'unidade': m.unidade.unidade,
#                        'SEI': m.sei_gerado,
#                        'usuário': m.usuario.username,
#                        }
#             context += [entrada]
#
#         context = {'data': context}
#
#         return render(request, 'core/3_acoes_cadastradas.html', context=context)
#
# @login_required
# @api_view(['GET', 'POST'])
# def modelos(request):
#     if request.method == 'GET':
#
#         if len(request.GET) == 0:
#             return render(request, 'core/4_modelos_main.html')
#
#         else:
#             response = FileResponse(open(request.GET['modelo'], 'rb'), as_attachment=True)
#             os.remove(request.GET['modelo'])
#             return response
#     else:
#         origem = request.POST.get('origem')
#         value = request.POST.get('value')
#
#         if origem == "modelo_cnj":
#
#             s_siajd = login.get_siajd_looged_session()
#             dados_processo = scrapper.get_siajd(s_siajd, request.POST.get('cnj_usuario'))
#
#             return render(request, 'core/4_modelos_grid_dados.html', context=dados_processo)
#
#         if origem == "modelos_disponiveis":
#             unidade = Unidade.objects.filter(unidade=request.POST.get('unidade'))
#             modelos_disponiveis = ModelosPeticoes.objects.filter(unidade__in=unidade)
#             modelos_disponiveis = [i for i in modelos_disponiveis]
#
#             return render(request, 'core/4_modelos_modelos_disponiveis.html', context={'parametros': modelos_disponiveis})
#
#
#         if origem == 'grid_modelo_selecionado':
#
#             crit_k = re.compile('campos_preenchidos\[modelo_|\]')
#
#             dados_siajd = [re.sub(crit_k, '', k) for k in request.POST.dict().keys() if 'campos_preenchidos' in k]
#
#             doc = ModelosPeticoes.objects.get(id=request.POST.get('modelo_id'))
#             doc = Document(doc.modeloarquivo.open())
#
#             t = ''
#             for p in doc.paragraphs:
#                 t += p.text
#             params = re.findall('{(.*?)}', t)
#             context = {'parametros': [i for i in params if i not in dados_siajd]}
#
#             return render(request, 'core/4_modelos_grid_dados_peticao.html', context=context)
#
#         if origem == "gerar_peticao":
#
#             crit_k = re.compile('campos_preenchidos\[modelo_|\]|[\{\}]|\s')
#
#
#             parametros_pet = {re.sub(crit_k, '', k):v for k,v in request.POST.dict().items() if 'campos_preenchidos' in k}
#
#
#             doc = ModelosPeticoes.objects.get(id=request.POST.dict()['modelo_id'])
#             nome = doc.modelonome.replace('/','_')
#             doc = Document(doc.modeloarquivo.open())
#
#             coletar = False
#             coleta = []
#
#             for p in doc.paragraphs:
#                 for r in p.runs:
#
#                     if '{' in r.text:
#                         if '}' not in r.text:
#                             coletar = True
#                         substituir = r
#
#                     if coletar:
#                         coleta += [r]
#
#                     if '}' in r.text:
#                         coleta.append(r)
#
#                         k = ''.join([i.text for i in coleta]).lower()
#                         k = re.sub(crit_k, '', k)
#
#                         substituir.text = parametros_pet[k].upper()
#                         for item in coleta[1:]:
#                             item.clear()
#
#                         coletar = False
#                         coleta = []
#
#
#             x = tempfile.NamedTemporaryFile(prefix = nome + '-', suffix='.docx', dir=os.path.join(settings.BASE_DIR, 'app','arquivos','peticoes_temp'), delete=False)
#             doc.save(x)
#             return JsonResponse({'modelo': x.name})
