from django.contrib import admin
from .models import *
# Register your models here.

admin.site.register(Unidade)
admin.site.register(Modelos)
admin.site.register(ModelosCriteiros)

admin.site.register(Objeto)
admin.site.register(ComplementoObjeto)
admin.site.register(Etapa)
