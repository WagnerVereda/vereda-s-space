# from django.shortcuts import render
# from rest_framework.decorators import api_view
# from django.http import HttpResponse
# import re
# from api.models import *
# from utils import login, scrapper
# from django.contrib.auth.decorators import login_required
# import datetime
# from django.http import JsonResponse, FileResponse
# import json
# from core.models import *
#
# # Create your views here.
#
# @api_view(['POST'])
# def recebe_processos(request):
#
#     params = request.POST.dict()
#     params = json.loads(params['data'])
#
#     print(params)
#
#     if params['requisicao'] == 'comunicar_processos':
#         modelos = [processo_recebido(fonte=params['fonte'], **i) for i in params['processos']]
#         processo_recebido.objects.bulk_create(modelos)
#
#         return HttpResponse(f'Requisicao recebida. Número total de processos: {len(modelos)}')
#
#     elif params['requisicao'] == 'processos_em_aberto':
#
#         q = processo_recebido.objects.filter(processado=False).values('id', 'nuprocessounificadoformatado')
#         q = [i for i in q]
#
#         return JsonResponse({'data': q})
#
#     elif params['requisicao'] == 'insere_processo':
#
#         if Informacoes.objects.filter(nuprocessounificadoformatado=params['processo_recebido']['nuprocessounificadoformatado']).exists():
#             m = processo_recebido.objects.get(id=params['processo_recebido']['id'])
#             m.processado = True
#             m.resultado = "Processo já recebido"
#             m.save()
#
#         else:
#             if 'data_inicial' in params['informacoes'].keys():
#                 params['informacoes']['data_inicial'] = datetime.datetime.strptime(params['informacoes']['data_inicial'], '%d/%m/%Y').date()
#
#             docinformacao = Informacoes(**{k: v for k, v in params['informacoes'].items() if k not in ['movimentacoes', 'partes', 'documentos']})
#             docinformacao.save()
#
#             if 'documentos' in params['informacoes'].keys():
#                 params['informacoes']['documentos'] = [{k: (v if k !=  'dtinclusao' else datetime.datetime.strptime(v, '%d/%m/%Y %H:%M:%S')) for k,v in i.items() } for i in params['informacoes']['documentos'] ]
#
#                 lista = [Documentos(**i, informacao=docinformacao) for i in params['informacoes']['documentos']]
#
#                 try:
#                     Documentos.objects.bulk_create(lista)
#                 except:
#                     for c in lista:
#                         try:
#                             c.save()
#                         except:
#                             pass
#
#             if 'partes' in params['informacoes'].keys():
#                 lista = [Partes(**i, informacao=docinformacao) for i in params['informacoes']['partes']]
#                 Partes.objects.bulk_create(lista)
#
#             if 'movimentacoes' in params['informacoes'].keys():
#                 params['informacoes']['movimentacoes'] = [{k: (v if k !=  'data' else datetime.datetime.strptime(v, '%d/%m/%Y').date()) for k,v in i.items() } for i in params['informacoes']['movimentacoes'] ]
#                 lista = [Movimentacoes(**i, informacao=docinformacao) for i in params['informacoes']['movimentacoes']]
#                 Movimentacoes.objects.bulk_create(lista)
#
#             if 'intimacao' in params['informacoes']:
#                 lista = [Intimacao(**i, informacao=docinformacao) for i in params['informacoes']['intimacao']]
#                 Intimacao.objects.bulk_create(lista)
#
#             m = processo_recebido.objects.get(id=params['processo_recebido']['id'])
#             m.processado = True
#             m.resultado = "Processo registrado"
#             m.save()
#
#
#         return HttpResponse(m.resultado)
