import requests
from bs4 import BeautifulSoup as bs
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


def get_siajd_looged_session():
    s = requests.session()
    url_login = 'https://siajd.pgm.prefeitura.sp.gov.br/UC_AUT_001_AutenticarUsuario/Login'

    data = {'Usuario': 'D858414',
            'Senha': '013451Ab',
            'TextoCaptcha': ''}

    s.post(url_login, data=data)

    return s


def get_sei_logged_session():

    s = requests.session()

    url_login = 'https://sip.prefeitura.sp.gov.br/sip/login.php?sigla_orgao_sistema=PMSP&sigla_sistema=SEI&infra_url=L3NlaS8='

    r = s.get(url_login)
    sp = bs(r.content, 'html5lib')

    hdnCaptcha = sp.find(attrs={'id': 'hdnCaptcha'}).get('value')

    data = {
        'txtUsuario': 'd858414',
        'pwdSenha': '013450Ab',
        'selOrgao': '11',
        'sbmLogin': 'Acessar',
        'hdnCaptcha': hdnCaptcha, }

    s.post(url_login, data=data)

    return s


def get_esaj_logged_session():
    s = requests.session()

    url = 'https://esaj.tjsp.jus.br/sajcas/login?service=https%3A%2F%2Fesaj.tjsp.jus.br%2Fesaj%2Fj_spring_cas_security_check'

    r = s.get(url, verify=False)

    sp = bs(r.content, 'html5lib')

    execution = sp.find('input', attrs={'id': 'flowExecutionKey'}).get('value')

    h = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
        'Accept-Encoding': 'gzip, deflate, br',
        'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
        'Cache-Control': 'max-age=0',
        'Connection': 'keep-alive',
        'Content-Length': '4531',
        'Content-Type': 'application/x-www-form-urlencoded',
        'DNT': '1',
        'Host': 'esaj.tjsp.jus.br',
        'Origin': 'https://esaj.tjsp.jus.br',
        'Upgrade-Insecure-Requests': '1',

    }

    params = {'service': 'https://esaj.tjsp.jus.br/esaj/j_spring_cas_security_check'}

    data = {
        'username': '013.787.440-55',
        'password': 'rasengan',
        'execution': execution,
        'lt': '',
        '_eventId': 'submit',
        'pbEntrar': 'Entrar',
        'signature': '',
        'certificadoSelecionado': '',
        'certificado': ''}

    s.post(url, data=data, headers=h, params=params)

    return s
