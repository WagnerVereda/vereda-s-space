
function navegacao(){
  var target = $(this).attr("href").substring(1);

  $("#frame_conteudo").load(target);

}

$(document).on('click', "a[id^='button_']", navegacao)
