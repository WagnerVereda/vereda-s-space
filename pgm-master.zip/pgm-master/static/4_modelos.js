var csrfmiddlewaretoken = $( "input[name*='csrfmiddlewaretoken']" ).attr('value')

function get_dados_processo() {
    var cnj_usuario = $('#modelo_cnj').val();

    if (cnj_usuario.length == 25){
      $( "#modelo_cnj" ).prop( "disabled", true );
      var parametros = {"origem": "modelo_cnj",
                        "cnj_usuario": cnj_usuario,
                        "csrfmiddlewaretoken" : csrfmiddlewaretoken};

      $("#dados_processo").load("modelos", parametros, get_modelos_disponiveis);

    }

    }


function get_modelos_disponiveis(){

  var parametros = {"origem": "modelos_disponiveis",
                    "unidade": $("#modelo_unidade").attr("value"),
                    "objeto": $("#modelo_objeto").attr("value"),
                    "csrfmiddlewaretoken" : csrfmiddlewaretoken};

  $("#modelos_disponiveis").load("modelos", parametros)
  }

function get_parametros_modelo(){
  var modelo_id = $("#grid_modelo_selecionado").children("option:selected").val();
  campos_preenchidos = $( "input[name*='modelo_dado_processo']" );

  criterios_e_valores = {'modelo_cnj': $('#modelo_cnj').val()};

  $.each(campos_preenchidos, function(k, v){
     criterios_e_valores[v.id] = v.value
   });

  var parametros = {"origem": "grid_modelo_selecionado",
                    "modelo_id" : modelo_id,
                    "campos_preenchidos" : criterios_e_valores,
                    "csrfmiddlewaretoken" : csrfmiddlewaretoken};

  $("#dados_modelo").load("modelos", parametros);

}


function gerar_peticao(){

  var modelo_id = $("#grid_modelo_selecionado").children("option:selected").val();

  campos_preenchidos = $( "input[name*='modelo_dado_processo']" );

  $.each(campos_preenchidos, function(k, v){
     criterios_e_valores[v.id] = v.value
   });

   var parametros = {"origem": "gerar_peticao",
                     "modelo_id" : modelo_id,
                     "campos_preenchidos" : criterios_e_valores,
                     "csrfmiddlewaretoken" : csrfmiddlewaretoken};

   $.post("modelos", parametros, function(result) {
       location.replace("modelos?modelo=" + result["modelo"])})

}

$(document).on('click', '#gerar_peticao', gerar_peticao)
$(document).on('keyup', '#modelo_cnj', get_dados_processo)
$(document).on('change', '#grid_modelo_selecionado', get_parametros_modelo)


// function gerar_peticao(){
//
//   var modelo_id = $("#grid_modelo_selecionado").children("option:selected").val();
//
//   campos_preenchidos = $( "input[name*='dado_processo']" );
//   criterios_e_valores = {'cnj': $('#cnj').val()};
//
//   $.each(campos_preenchidos, function(k, v){
//      criterios_e_valores[v.id] = v.value
//    });
//
//    var parametros = {"origem": "gerar_peticao",
//                      "modelo_id" : modelo_id,
//                      "campos_preenchidos" : criterios_e_valores,
//                      "csrfmiddlewaretoken" : csrfmiddlewaretoken};
//
//    $.post("peticoes", parametros, function(result) {
//        location.replace("peticoes?document_id=" + result["document_id"])})
//
// }
//
// $(document).on('click', '#gerar_peticao', gerar_peticao)
